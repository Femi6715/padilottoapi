module.exports = {
    database: "mongodb://simplelottoadmin:adminsimplelotto@mongodb-2534-0.cloudclusters.net:10013/simplelotto?authSource=admin",
    secret: "whatismysecret"
}